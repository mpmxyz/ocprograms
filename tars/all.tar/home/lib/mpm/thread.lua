-- lua multithreading
local event = require("event")


local threads = {}
local filters = {}
local count = 0
local thread = {}
function thread.start(func)
  count = count + 1
  threads[count] = coroutine.create(func)
  filters[count] = nil
end

function thread.run(onError)
  os.queueEvent("init")
  onError = onError or error
  while count > 0 do
    local n = 1
    local eventData = {event.pull()}
    while n <= count do
      local routine = threads[n]
      if filters[n] == nil or filters[n] == eventData[1] or eventData[1] == "terminate" then
        local ok, param = coroutine.resume(routine, unpack(eventData, 1, table.maxn(eventData)))
        if not ok then
          onError( param )
        else
          filters[n] = param
        end
        if coroutine.status(routine) == "dead" then
          table.remove(threads, n)
          table.remove(filters, n)
          count = count - 1
          n = n - 1
        end
      end
      n = n + 1
    end
  end
end

return thread
