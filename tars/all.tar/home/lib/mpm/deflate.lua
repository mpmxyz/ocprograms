
local deflate = {}

function deflate.deflate(stream)
  
end
function deflate.inflate(stream)
  
end
