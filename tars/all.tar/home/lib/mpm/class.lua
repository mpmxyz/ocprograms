local Object={}

local function Class(...)
  local supers = {...}
  if supers[1] == nil then
    --no super classes implies Object as superclass
    supers[1] = Object
  end
  return function(content)
    local DO_CACHING = content.__cached
    content.supers  = supers  --remember super classes
    content.class   = content --to make objects able to refer to class
    content.__index = content --the class is the objects metatable
    content.__superList = {}  --cache for super classes
    local metatable = {}
    --inheritance
    if supers[2] == nil then
      --only one super class
      content.super     = supers[1]
      --Object has no __index metamethod
      if content ~= Object then
        metatable.__index = supers[1]
      end
    else
      --multiple super classes
      if DO_CACHING then
        local nils = {}
        function metatable.__index(t, key)
          if nils[key] then
            return nil
          end
          for _, super in ipairs(t.supers) do
            local value = super[key]
            if value ~= nil then
              t[key] = value
              return value
            end
          end
          if DO_CACHING ~= "nonil" then
            nils[key] = true
          end
          return nil
        end
      else
        function metatable.__index(t, key)
          for _, super in ipairs(t.supers) do
            local value = super[key]
            if value ~= nil then
              return value
            end
          end
          return nil
        end
      end
    end
    --Schreibschutz f�r metatable
    metatable.__metatable="blocked"
    --Konstruktur-Aufruf
    local tableBuffer={}  --zum Vermeiden von unn�tig erstellten tables 
    --Konstruktor-Konvention: Bei R�ckgabe von Ersatz-table wird self nicht ver�ndert.
    function content:new(...)
      local newTable=tableBuffer
      setmetatable(newTable,self) --Setzen der Klasse
      local init=self.__init
      if type(init)=="function" then
        --�ndern der Objekttable m�glich. (z.B. durch �bernahme aus Parameter)
        local otherTable=init(newTable,...)
        if otherTable~=nil and otherTable~=newTable then
          setmetatable(otherTable,self) --Setzen der Klasse
          return otherTable
        end
      end
      tableBuffer={}
      return newTable
    end
    --Typ�berpr�fung
    function content:is(class)
      if type(class)~="table" then
        error("Expecting")
      end
      --Pr�fe, ob Ergebnis schon bekannt
      local result=self.__superList[class]
      if result~=nil then
        return result
      end
      if class==content or class==Object then
        --keine Suche im Vererbungsbaum notwendig
        result=true
      else
        --Pr�fe Ergebnis auf umst�ndliche Art und Weise bei den Unterklassen
        result=false
        local i,superClass
        for i,superClass in ipairs(self.supers) do
          if superClass:is(class) then
            result=true
            break
          end
        end
      end
      self.__superList[class]=result
      return result
    end
    setmetatable(content, metatable)
    return content
  end
end

--Object is its own super class
Object = Class(Object)(Object)

return Class
--[[
  Test=Class(super){
    __init = function(self,params)
      
    end,
  }
  
]]--
