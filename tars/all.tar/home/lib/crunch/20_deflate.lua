-----------------------------------------------------
--name       : lib/crunch/20_deflate.lua
--description: crunch module, writes deflate prefix, wraps the stream (compression + suffix on close, requires data card)
--author     : mpmxyz
--github page: https://github.com/mpmxyz/ocprograms
--forum page : none
-----------------------------------------------------
return {
  run = function(context, options)
    if options.deflate then
      --TODO
    end
  end,
}
