-----------------------------------------------------
--name       : lib/crunch/24_variable_prefix.lua
--description: crunch module, adds 'local a,b,c="hello", 123456789...' prefix on top of the file
--author     : mpmxyz
--github page: https://github.com/mpmxyz/ocprograms
--forum page : none
-----------------------------------------------------
return {
  run = function(context, options)
    --TODO
  end,
}
